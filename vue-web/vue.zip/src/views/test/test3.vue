<template>
    <div>
        Feature 3
    </div>
</template>

<script>
export default{

}

</script>

<style>

</style>